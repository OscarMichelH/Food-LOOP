require 'rltk/lexer'
module FoodLOOP
  class Lexer < RLTK::Lexer
    rule(/menu/) { :PROGRAM }
    rule(/mostrar/)   { :PRINT   }
    rule(/ingrediente/) { :VAR }
    rule(/si/) { :IF }
    rule(/sino/) { :ELSE }
    rule(/&&/) { :AND }
    rule(/||/) { :OR }
    rule(/>/)   { :GT }
    rule(/</)   { :LT }
    rule(/nocortable/) { :INTEGER }
    rule(/cortable/) { :FLOAT }
    rule(/nombre/) { :STRING }
    rule(/estado/) { :BOOLEAN }
    rule(/proceso/) { :VOID }
    rule(/receta/) { :FUNCTION }
    rule(/terminar/) { :END }
    rule(/servir/) { :RETURN }
    rule(/traer/) { :INPUT }
    rule(/repetir_mientras/) { :WHILE }
    rule(/platillo/) { :CLASS }

    rule(/\".*\"/) { |t| [:WORD, t] }

    # Identifier num
    rule(/[-]?[1-9][0-9]*/) {|t| [:NUM_I, t.to_i] }
    rule(/[-]?[1-9][0-9]*(\.[0-9]+)?/) {|t| [:NUM_F, t.to_f]}

    # Identifier rule.
    rule(/[A-Za-z][A-Za-z0-9]*/) { |t| [:ID, t] }

    # Operators and delimiters.
    rule(/\(/)  { :LPAREN }
    rule(/\)/)  { :RPAREN }
    rule(/\{/)  { :LKEY }
    rule(/\}/)  { :RKEY }
    rule(/=/)  { :EQUAL }
    rule(/<>/)  { :DIF }
    rule(/==/)  { :SIMILAR }
    rule(/,/)   { :COMMA}
    rule(/:/)   { :DDOT}
    rule(/;/)   { :SEMI }

    rule(/\+/)  { :PLUS }
    rule(/-/)   { :SUB  }
    rule(/\//)  { :DIV  }
    rule(/\*/)  { :MUL  }
    rule(/<</)  { :INHERITS  }
    rule(//)  { :EPSILON  }

    #WhiteSpaces
    rule(/\s/)
  end
end