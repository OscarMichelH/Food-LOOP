require './flLexer.rb'
require './flParser.rb'

# line_counter = 0
# notCrash = true
# File.open('test.fl', 'r').each do |line|
#     line_counter = line_counter + 1
#     begin
#         begin
#             ast = FoodLOOP::Lexer.lex(line)
#         rescue 
#             puts 'Lexical Eroor'
#         end
#         ast = FoodLOOP::Parser.parse(FoodLOOP::Lexer.lex(line))
#     rescue
#         puts 'Syntax Error in line: ' + line_counter.to_s
#         notCrash = false
#     end
# end

begin
    line = gets.chomp

    # puts FoodLOOP::Lexer.lex(line)

    ast = FoodLOOP::Parser.parse(FoodLOOP::Lexer.lex(line))
    puts ast
rescue RLTK::LexingError, RLTK::NotInLanguage
    puts 'Linea no esta en lenguaje'
end

# if (notCrash)
#     puts "Successful Loading"
# else
#     puts "Loading Error"
# end