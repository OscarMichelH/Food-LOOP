require 'rltk/parser'
require 'rltk/ast'

module FoodLOOP
    class Parser < RLTK::Parser
        #Constructors:

        # clause('NUM_F')	{ |n| Number.new(n)   }
        # clause('ID')	{ |i| Variable.new(i) }

        production(:statement) do
            clause('exp') {|e| e}
            clause('inp') {|i| i}
        end

        production(:inp, 'INPUT LPAREN RPAREN') { |_, _, _| gets }

        production(:exp) do
            clause('exp PLUS ter') {|t0, _, t1| t0 + t1}
            clause('exp SUB ter') {|t0, _, t1| t0 - t1}
            clause('ter'){|f0|f0}
        end

        production(:ter) do
            clause('ter MUL fac') {|f0, _, f1| f0 * f1}
            clause('ter DIV fac') {|f0, _, f1| f0 / f1}
            clause('fac'){|f0|f0}
        end

        production(:fac) do
            clause('ID as')  {|_, as| as }
            clause('LPAREN me RPAREN') { |_, me, _| me }
            clause('NUM_I') { |i0| i0 }
            clause('inp') { |i0| i0.to_i }
        end

        production(:as) do
            clause('LKEY exp RKEY')  { |_, exp, _| exp }
        end

        production(:me) do
            clause('se')  { |s0| s0 }
            clause('se AND se')  { |s0, _, s1| s0 and s1 }
            clause('se OR se') { |s0, _, s1| s0 or s1}
        end

        production(:se) do
            clause('exp')  { |exp| exp }
            clause('exp GT exp')  { |e0, _, e1| e0 > e1 }
            clause('exp LT exp') { |e0, _, e1| e0 < e1}
            clause('exp DIF exp') { |e0, _, e1| e0 != e1}
            clause('exp SIMILAR exp') { |e0, _, e1| e0 == e1}
        end

        ###
        finalize
    end
end